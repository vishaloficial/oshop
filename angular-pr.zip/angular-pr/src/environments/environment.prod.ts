export const environment = {
  production: true,
  firebase:{
    apiKey: "AIzaSyCpQAFWQhMBmoPfuWlumuaskM5j3-iRRfw",
    authDomain: "fir-demo-d8b34.firebaseapp.com",
    databaseURL: "https://fir-demo-d8b34-default-rtdb.europe-west1.firebasedatabase.app",
    projectId: "fir-demo-d8b34",
    storageBucket: "fir-demo-d8b34.appspot.com",
    messagingSenderId: "983868882701",
    
  }
};
