import { Component, OnInit } from '@angular/core';
import { CategoryService } from 'src/app/category.service';
import {Observable} from 'rxjs'
import { ProductserviceService } from 'src/app/productservice.service';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';


@Component({
  selector: 'app-product-form',
  templateUrl: './product-form.component.html',
  styleUrls: ['./product-form.component.css']
})
export class ProductFormComponent  {
categories:any;
product:any={};
id:any;
  constructor( categoryService:CategoryService,
    private router :Router,
    private route:ActivatedRoute,
     private productService:ProductserviceService) { 
 
 categoryService.getCategories()
 .valueChanges()
 .subscribe(val => {
   this.categories = val;
   console.log(val);
 });

 this.id=this.route.snapshot.paramMap.get('id');
 if(this.id) {
  productService.getProductById(this.id)
  .valueChanges()
  .subscribe(val => {
    this.product = val;
    console.log(  this.product);
  });

 }
 console.log(this.product)
  }
save(product:any){
if(this.id) this.productService.update(this.id,product);
else this.productService.create(product);
this.router.navigate(['/admin/products']);
}

delete(){
  if(confirm('Are you sure you want to delete this product')){
    this.productService.delete(this.id);
    this.router.navigate(['/admin/products']);
  }
}
 
}
