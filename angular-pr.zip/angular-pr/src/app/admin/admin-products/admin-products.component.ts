import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subject, Subscription } from 'rxjs';
import { Product } from 'src/app/models/products';
import { ProductserviceService } from 'src/app/productservice.service';

@Component({
  selector: 'app-admin-products',
  templateUrl: './admin-products.component.html',
  styleUrls: ['./admin-products.component.css']
})
export class AdminProductsComponent implements OnInit, OnDestroy {
  products:Product[]=[];
 productold:any=[];
  filteredProducts:any=[];
  dtTrigger: Subject<any> = new Subject<any>();

  subscription:Subscription;
  constructor( private productService:ProductserviceService) {
   

   this.subscription= productService.getAll().snapshotChanges().subscribe(actions => {
      for(let i=0;i<actions.length;i++){
this.productold[i]=actions[i].payload.val();
this.productold[i].key=actions[i].payload.key;
        this.products[i]=this.productold[i]
        this.products[i].key=this.productold[i].key
             }
       this.filteredProducts=this.products;
       this.dtTrigger.next();
      });


   }

filter(query:string){
 this.filteredProducts=(query)?
this.products.filter(p=>p.title.toLowerCase().includes(query.toLowerCase())):
this.products;
}

ngOnDestroy(){
  this.subscription.unsubscribe();
  this.dtTrigger.unsubscribe();
}


dtOptions: DataTables.Settings = {};

  ngOnInit(): void {
    this.dtOptions = {
      pagingType: 'full_numbers'
    };
  }
}
