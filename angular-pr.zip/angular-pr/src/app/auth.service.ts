import { Injectable } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/auth';
import * as firebase from 'firebase';

import { AngularFireModule } from '@angular/fire';
import { ActivatedRoute } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthService {  

  constructor( private asAuth:AngularFireAuth, private route:ActivatedRoute) { }

  login(){
    let returnUrl=this.route.snapshot.queryParamMap.get('returnUrl') || '/';
    localStorage.setItem('returnUrl', returnUrl);
    this.asAuth.auth.signInWithRedirect( new firebase.auth.GoogleAuthProvider());
  }
  logout(){
    this.asAuth.auth.signOut();
  }
}
