import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, RouterStateSnapshot } from '@angular/router';
import { AuthService } from './auth.service';
import {Router } from '@angular/router'
import { AngularFireAuth } from '@angular/fire/auth';

@Injectable({
  providedIn: 'root'
})
export class AuthGaurdService implements CanActivate{

  constructor(private auth:AngularFireAuth, private router:Router) { }

  canActivate(route:ActivatedRouteSnapshot, state:RouterStateSnapshot){
 this.auth.user.subscribe(userResponse=>{
  if(userResponse) return true;
  this.router.navigate(['/login'],{queryParams:{returnUrl:state.url}});
  return false;
})
return true;
  }
}
