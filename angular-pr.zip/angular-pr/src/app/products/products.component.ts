import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CategoryService } from '../category.service';
import { Product } from '../models/products';
import { ProductserviceService } from '../productservice.service';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent  {
products:Product[]=[];
productold:any=[];
filteredProducts:Product[]=[];
categories:any;
category:any; 
  constructor( productService:ProductserviceService, categoryService:CategoryService,route:ActivatedRoute) {

    productService.getAll().snapshotChanges().subscribe(actions => {
      for(let i=0;i<actions.length;i++){
this.productold[i]=actions[i].payload.val();
this.productold[i].key=actions[i].payload.key;
        this.products[i]=this.productold[i]
        this.products[i].key=this.productold[i].key
             }
       this.filteredProducts=this.products;
   
      });

    categoryService.getCategories().valueChanges().subscribe(x=>this.categories=x);

    route.queryParamMap.subscribe(params=>{
      this.category= params.get('category')

      this.filteredProducts=(this.category)?
      this.products.filter(p=>p.category===this.category):
      this.products; 
    })
   }

 
}
