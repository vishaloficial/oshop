import { Component, OnInit } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/auth';
import * as firebase from 'firebase';
import { Observable, of } from 'rxjs';
import { AuthService } from '../auth.service';

@Component({
  selector: 'bs-navbar',
  templateUrl: './bs-navbar.component.html',
  styleUrls: ['./bs-navbar.component.css']
})
export class BsNavbarComponent  {
 user:any;
 userLoggedIn:any;
 isAdmin:any;
  constructor( private afAuth:AngularFireAuth , private logService:AuthService) { 
    this.afAuth.authState.subscribe(userResponse => {
      if (userResponse) {
        if(userResponse.email=="vishaloficial@gmail.com" || "shahharshita.26@gmail.com"){
          this.isAdmin=true
        }else{
          this.isAdmin=false;
        }
      this.userLoggedIn=true;
      
        console.log(userResponse);
        this.user=userResponse.displayName;
        
      } else {
        this.userLoggedIn=false;
      }
    });
  }

 logout(){
this.logService.logout();
 this.userLoggedIn=false;
 }

}
