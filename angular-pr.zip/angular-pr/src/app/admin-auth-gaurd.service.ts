import { Injectable } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/auth';
import { CanActivate } from '@angular/router';
import { Observable } from 'rxjs';
import { AppComponent } from './app.component';
import { UserService } from './user.service';


@Injectable({
  providedIn: 'root'
})
export class AdminAuthGaurdService implements CanActivate {
user:any=false;

  constructor(private auth:AngularFireAuth, private userservice:UserService , private app:AppComponent) {

  
   }


  canActivate(){
    this.auth.authState.subscribe(userResponse=>{
      if(userResponse?.email=="vishaloficial@gmail.com" || "shahharshita.26@gmail.com"){
        
        this.user=true;
    }
      
  });
  
  return  this.user;
}
}