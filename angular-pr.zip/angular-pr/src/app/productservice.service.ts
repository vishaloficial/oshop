import { Injectable } from '@angular/core';
import { AngularFireDatabase } from '@angular/fire/database';

@Injectable({
  providedIn: 'root'
})
export class ProductserviceService {

  constructor( private db:AngularFireDatabase) {
 
   }
   create(products:any){
    
   return this.db.list('products').push(products);
   }

   getAll(){
     return this.db.list('/products');
   }
   getProductById(productId:any){
return this.db.object('/products/'+ productId)
   }

   update(productId:any, product:any){
return this.db.object('/products/' +  productId).update(product);
   }

   delete(productId:any){
    return this.db.object('/products/' +  productId).remove();

   }
}
