import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import{RouterModule} from '@angular/router';
import{NgbModule} from '@ng-bootstrap/ng-bootstrap';
import {FormsModule} from '@angular/forms';
import {CustomFormsModule} from 'ng2-validation';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AngularFireModule } from 'angularfire2'; 
import { AngularFireDatabaseModule } from 'angularfire2/database';
import { AngularFireAuthModule} from 'angularfire2/auth';
import { environment } from 'src/environments/environment';
import { BsNavbarComponent } from './bs-navbar/bs-navbar.component';
import { HomeComponent } from './home/home.component';
import { ProductsComponent } from './products/products.component';
import { ShopingCartComponent } from './shoping-cart/shoping-cart.component';
import { CheckOutComponent } from './check-out/check-out.component';
import { OrderSuccessComponent } from './order-success/order-success.component';
import { MyOrdersComponent } from './my-orders/my-orders.component';
import { AdminProductsComponent } from './admin/admin-products/admin-products.component';
import { AdminOrdersComponent } from './admin/admin-orders/admin-orders.component';
import { LoginComponent } from './login/login.component';
import { AuthService } from './auth.service';
import { AuthGaurdService as AuthGaurd } from './auth-gaurd.service';
import { UserService } from './user.service';
import { AdminAuthGaurdService as AdminAuthGaurd } from './admin-auth-gaurd.service';
import { ProductFormComponent } from './admin/product-form/product-form.component';
import { CategoryService } from './category.service';
import { DataTablesModule } from "angular-datatables";



@NgModule({
  declarations: [
    AppComponent,
    BsNavbarComponent,
    HomeComponent,
    ProductsComponent,
    ShopingCartComponent,
    CheckOutComponent,
    OrderSuccessComponent,
    MyOrdersComponent,
    AdminProductsComponent,
    AdminOrdersComponent,
    ProductFormComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    CustomFormsModule,
    AngularFireModule.initializeApp(environment.firebase),
    AngularFireDatabaseModule,
    NgbModule,
    AngularFireAuthModule,
    DataTablesModule,
    RouterModule.forRoot([
      {path:'', component:ProductsComponent},
      {path:'orders', component:MyOrdersComponent,canActivate:[AuthGaurd]},
      {path:'products', component:ProductsComponent},
      {path:'shoping-cart', component:ShopingCartComponent},
      {path:'login', component:LoginComponent},
      {path:'check-out', component:CheckOutComponent, canActivate:[AuthGaurd]},
      {path:'order-success', component:OrderSuccessComponent, canActivate:[AuthGaurd]},
   
      
      {path:'admin/products/new', component:ProductFormComponent, canActivate:[AuthGaurd,AdminAuthGaurd]},
      {path:'admin/products/:id', component:ProductFormComponent, canActivate:[AuthGaurd,AdminAuthGaurd]},
      {path:'admin/products', component:AdminProductsComponent, canActivate:[AuthGaurd,AdminAuthGaurd]},
      {path:'admin/orders', component:AdminOrdersComponent, canActivate:[AuthGaurd,AdminAuthGaurd]},
      

    ])
  ],
  providers: [
    AuthService,
    AuthGaurd,
   UserService,
   AdminAuthGaurd,
   AppComponent,
   CategoryService
  
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
