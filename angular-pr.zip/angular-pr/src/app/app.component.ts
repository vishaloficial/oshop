import { Component } from '@angular/core';
import * as firebase from 'firebase/app';
import {Router } from '@angular/router'
import { AngularFireAuth } from '@angular/fire/auth';
import { UserService } from './user.service';
import { stringify } from '@angular/compiler/src/util';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  userid1:any;
 
  constructor(private userservice:UserService, private auth:AngularFireAuth, private router:Router) { 


    this.auth.authState.subscribe(userResponse=>{
      if(userResponse){
        this.userid1=userResponse.uid
        userservice.save(userResponse);
       
        let returnUrl:any = localStorage.getItem('returnUrl');
        if(returnUrl){
          localStorage.removeItem('returnUrl');
          router.navigateByUrl(returnUrl);
        
        }
        
    }
      
  });
    
  }







}

  